// signalhunter.cpp — RSSI "hot/cold" locator (native ProtoKill style)
// Part of DIVV2-CUSTOMFIRMWARE-PCB (DEMRCAN2)
// Your own networks / authorised use only.

#include "config.h"
#include "icon.h"

namespace SignalHunter {

#define C_BG   BLACK
#define C_TXT  UI_TEXT
#define C_ORA  ORANGE
#define C_GRN  GREEN
#define C_RED  RED
#define C_GRY  GRAY
#define SH_BAR2       0x2104
#define SH_HEADER_Y   44
#define SH_FIRST_ROW  66
#define SH_ROW_H      22
#define SH_LOG_TOP    62
#define SH_LINE_H     12

static inline void shFont() { tft.setTextFont(1); tft.setTextSize(1); }
static int shBottom() { return featureHasTouchNavBar() ? touchNavContentBottomY() : 320; }

static void shNav(const char* l, const char* d, const char* c, const char* u, const char* r) {
  setTouchNavLabels(l, d, c, u, r);
  redrawTouchButtonBar();
}
static void topBar(bool rescan) {
  tft.fillRect(0, 20, 240, 16, SH_BAR2);
  tft.drawBitmap(10, 20, bitmap_icon_go_back, 16, 16, C_TXT);
  if (rescan) tft.drawBitmap(214, 20, bitmap_icon_undo, 16, 16, C_TXT);
}
static void header(const char* t, bool rescan, uint16_t col) {
  featureClearContent(C_BG);
  drawStatusBar(readBatteryVoltage(), true, false);
  tft.drawFastHLine(0, 19, 240, UI_LINE);
  topBar(rescan);
  shFont();
  tft.setTextColor(col, C_BG);
  tft.setCursor(6, SH_HEADER_Y);
  tft.print(t);
}

enum State { ST_SCAN, ST_SELECT, ST_HUNT };
static State st = ST_SCAN;

struct Ap { char ssid[33]; uint8_t bssid[6]; uint8_t ch; int8_t rssi; bool open; };
static const int MAXAP = 24;
static Ap  aps[MAXAP];
static int nAp = 0, cursor = 0, viewTop = 0;

static uint8_t tBssid[6];
static uint8_t tCh = 1;
static char    tSsid[25];
static int     rssi = -100, prevRssi = -100, peak = -127;
static uint32_t lastScan = 0;
static bool    needList = true;
static bool    huntFrame = false;

// flowing terminal log: stores each reading's rssi + trend (0=warmer,1=colder,2=steady)
static const int LOGMAX = 12;
static int     logRssi[LOGMAX];
static uint8_t logTrend[LOGMAX];
static int     logN = 0;
static void logAdd(int r, uint8_t t) {
  if (logN < LOGMAX) { logRssi[logN] = r; logTrend[logN] = t; logN++; }
  else {
    for (int i = 0; i < LOGMAX - 1; i++) { logRssi[i] = logRssi[i + 1]; logTrend[i] = logTrend[i + 1]; }
    logRssi[LOGMAX - 1] = r; logTrend[LOGMAX - 1] = t;
  }
}

// ── scanning ──
static void doScan() {
  header("Signal Hunter", false, C_GRN);
  shFont();
  tft.setTextColor(C_GRY, C_BG);
  tft.setCursor(5, SH_LOG_TOP);               tft.print("[*] scanning all channels...");
  tft.setCursor(5, SH_LOG_TOP + SH_LINE_H*2); tft.setTextColor(C_TXT, C_BG); tft.print("[*] please wait");
  shNav(nullptr, nullptr, "Exit", nullptr, nullptr);

  int n = WiFi.scanNetworks(false, true);
  nAp = 0;
  for (int i = 0; i < n && nAp < MAXAP; i++) {
    String s = WiFi.SSID(i);
    if (s.length() == 0) s = "<hidden>";
    s.toCharArray(aps[nAp].ssid, sizeof(aps[nAp].ssid));
    memcpy(aps[nAp].bssid, WiFi.BSSID(i), 6);
    aps[nAp].ch   = WiFi.channel(i);
    aps[nAp].rssi = WiFi.RSSI(i);
    aps[nAp].open = (WiFi.encryptionType(i) == WIFI_AUTH_OPEN);
    nAp++;
  }
  WiFi.scanDelete();
  cursor = 0; viewTop = 0;
  st = ST_SELECT;
  needList = true;
}

// ── selection list (identical to the Handshake network picker) ──
static void drawList() {
  header("Networks:", true, C_GRN);
  const int rowH = 22;
  const int top = SH_FIRST_ROW;
  int rows = (shBottom() - top) / rowH;
  if (rows < 1) rows = 1;
  if (nAp == 0) {
    shFont(); tft.setTextColor(C_ORA, C_BG);
    tft.setCursor(5, top); tft.print("[!] no networks - Back");
    shNav(nullptr, nullptr, "Exit", nullptr, nullptr);
    needList = false; return;
  }
  if (cursor < viewTop) viewTop = cursor;
  if (cursor >= viewTop + rows) viewTop = cursor - rows + 1;
  int pages = (nAp + rows - 1) / rows;
  shFont(); tft.setTextColor(C_GRN, C_BG);
  tft.setCursor(185, SH_HEADER_Y); tft.printf("Page %d/%d", (viewTop / rows) + 1, pages < 1 ? 1 : pages);
  for (int r = 0; r < rows; r++) {
    int i = viewTop + r;
    int y = top + r * rowH;
    tft.fillRect(0, y, 240, rowH, C_BG);
    if (i >= nAp) continue;
    bool sel = (i == cursor);
    char ssid[16];
    strncpy(ssid, aps[i].ssid, 11); ssid[11] = 0;
    if (strlen(aps[i].ssid) > 11) strcat(ssid, "...");
    char buf[48];
    snprintf(buf, sizeof(buf), "%02d: %-15s %3d dBm Ch%2d %s",
             i + 1, ssid, aps[i].rssi, aps[i].ch, aps[i].open ? "OPEN" : "WPA2");
    tft.setCursor(2, y);  tft.setTextColor(sel ? C_ORA : C_BG, C_BG); tft.print(sel ? ">" : " ");
    tft.setCursor(10, y); tft.setTextColor(sel ? C_ORA : C_TXT, C_BG); tft.print(buf);
  }
  shNav(nullptr, "Down", "Exit", "Up", "Select");   // RIGHT=Select, SELECT(45)=Exit
  needList = false;
}

static void startHunt() {
  memcpy(tBssid, aps[cursor].bssid, 6);
  tCh = aps[cursor].ch;
  strncpy(tSsid, aps[cursor].ssid, sizeof(tSsid));
  rssi = prevRssi = aps[cursor].rssi;
  peak = aps[cursor].rssi;
  lastScan = 0;
  logN = 0;
  huntFrame = false;
  st = ST_HUNT;
}

static void scanTarget() {
  int n = WiFi.scanNetworks(false, true, false, 220, tCh);
  int found = -127;
  for (int i = 0; i < n; i++) {
    if (memcmp(WiFi.BSSID(i), tBssid, 6) == 0) { found = WiFi.RSSI(i); break; }
  }
  WiFi.scanDelete();
  prevRssi = rssi;
  if (found > -127) rssi = found;
  if (rssi > peak) peak = rssi;
}

// layout: SSID/channel at top-left; the flowing log sits lower; vertical bar on
// the right spans (is proportional to) the log block.
#define VB_X     214
#define VB_W     10              // thin bar
#define VB_H     130             // long bar (centred on the log block)
#define LOG_TOP  96              // flowing log pulled down (channel/ssid stay up)
#define TXT_W    240            // full-width text (bar removed)

static int vbTop() { return (LOG_TOP + (shBottom() - 2)) / 2 - VB_H / 2 - 32; }

// static frame (drawn once per hunt): target top-left, vertical bar outline, nav
static void drawHuntFrame() {
  header("Locating", false, C_GRN);
  shFont();
  tft.setTextColor(C_TXT, C_BG); tft.setCursor(5, 44); tft.print(tSsid);
  char l[24]; snprintf(l, sizeof(l), "channel %d", tCh);
  tft.setTextColor(C_GRY, C_BG); tft.setCursor(5, 56); tft.print(l);
  shNav("Back", nullptr, "Exit", nullptr, nullptr);   // LEFT=Back, SELECT(45)=Exit
  huntFrame = true;
}

// live update: vertical bar fill + current % + segment-coloured flowing log
static void drawHuntUpdate() {
  int pct = ::map(constrain(rssi, -90, -30), -90, -30, 0, 100);
  uint16_t barC = pct > 66 ? C_GRN : (pct > 33 ? C_ORA : C_RED);

  shFont();
  // current signal % stays up near the header info
  char cur[20]; snprintf(cur, sizeof(cur), "signal  %d%%", pct);
  tft.fillRect(0, 72, TXT_W, 11, C_BG);
  tft.setTextColor(barC, C_BG); tft.setCursor(5, 72); tft.print(cur);

  // append reading (rssi + trend) to the flowing log
  int d2 = rssi - prevRssi;
  uint8_t t = (d2 > 1) ? 0 : (d2 < -1) ? 1 : 2;          // 0 warmer, 1 colder, 2 steady
  logAdd(rssi, t);

  // redraw log: "-53 dBm" + symbol coloured (green/red/gray), word in WHITE
  const int lh = 11;
  tft.fillRect(0, LOG_TOP, TXT_W, shBottom() - LOG_TOP, C_BG);
  for (int i = 0; i < logN; i++) {
    int y = LOG_TOP + i * lh;
    uint16_t tc = (logTrend[i] == 0) ? C_GRN : (logTrend[i] == 1) ? C_RED : C_GRY;
    const char* word = (logTrend[i] == 0) ? "WARMER" : (logTrend[i] == 1) ? "colder" : "steady";
    const char* sym  = (logTrend[i] == 0) ? " ^"     : (logTrend[i] == 1) ? " v"     : " -";
    tft.setCursor(5, y);
    tft.setTextColor(tc, C_BG);    tft.printf("%d dBm ", logRssi[i]);  // value coloured
    tft.setTextColor(C_TXT, C_BG); tft.print(word);                    // word white
    tft.setTextColor(tc, C_BG);    tft.print(sym);                     // symbol coloured
  }
}

void setup() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(60);
  st = ST_SCAN;
  feature_exit_requested = false;
  setTouchButtonInputEnabled(true);   // enable the footer control cards
}

void loop() {
  maintainTouchNavBar();               // keep the footer cards drawn
  switch (st) {
    case ST_SCAN:
      doScan();
      break;
    case ST_SELECT:
      if (needList) drawList();
      if (isButtonPressedEdge(BTN_UP))    { if (cursor > 0)       { cursor--; needList = true; } }
      if (isButtonPressedEdge(BTN_DOWN))  { if (cursor < nAp - 1) { cursor++; needList = true; } }
      if (isButtonPressedEdge(BTN_RIGHT)) { if (nAp > 0) startHunt(); }        // RIGHT = pick
      if (isButtonPressedEdge(BTN_LEFT) || featureExitButtonPressed()) {       // LEFT / SELECT(45) = exit
        feature_exit_requested = true;
      }
      delay(15);
      break;
    case ST_HUNT:
      if (!huntFrame) drawHuntFrame();
      if (millis() - lastScan > 300) { scanTarget(); drawHuntUpdate(); lastScan = millis(); }
      if (isButtonPressedEdge(BTN_LEFT)) { st = ST_SELECT; needList = true; }  // LEFT = back to list
      if (featureExitButtonPressed())    { feature_exit_requested = true; }    // SELECT(45) = exit
      delay(10);
      break;
  }
}

void exit() {
  WiFi.scanDelete();
  WiFi.mode(WIFI_OFF);
}

} // namespace SignalHunter
