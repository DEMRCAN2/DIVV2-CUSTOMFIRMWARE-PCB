// gps.cpp — GPS removed to save flash (no GPS hardware on this board).
// Only the public API from gps.h is kept as no-op stubs so the rest of the
// firmware still links. The full GPS implementation is in gps.cpp.fullbackup.
#include "gps.h"

namespace GpsSatelliteScanner {
  void session() {}
}

namespace GpsWardriver {
  void session() {}
  void stopBackgroundIfRunning() {}
  bool statusBarGpsIconActive() { return false; }
  void clearSessionRetry() {}
  bool consumeSessionRetry() { return false; }
}
