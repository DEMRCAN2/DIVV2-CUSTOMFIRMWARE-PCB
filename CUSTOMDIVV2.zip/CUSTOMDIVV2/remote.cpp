// remote.cpp — USB screen-mirror + control bridge (qFlipper-style)
// Part of DIVV2-CUSTOMFIRMWARE-PCB (DEMRCAN2)
//
// service() runs from the button-poll functions (UI thread, between draws) so
// there is no second task and no SPI contention. Full-resolution 240x320 is
// mirrored, but only the horizontal strips that actually CHANGED are sent
// (per-strip hash diff) — a static menu costs ~no bandwidth, so the UI loop
// stays fast and button taps stay snappy. A redraw (entering a feature) sends
// the changed strips over a few frames.
//
// Wire protocol (115200 -> 921600 in begin()):
//   host -> device (ASCII bytes): u d l r = D-pad | k = OK | 1 = on | 0 = off | p = ping
//   device -> host:
//       "DIM <w> <h>\n"                 once when streaming starts
//       "STR <y> <w> <h>\n" + w*h*2 B   per changed strip (RGB565 little-endian)
//       "DIV2\n"                        reply to ping
//
// LEGAL/scope: a control/mirror convenience for your own device.

#include "config.h"   // tft, Serial, BTN_*, TFT_eSPI, Arduino

namespace Remote {

// ───────── stream geometry ─────────
static const uint32_t BAUD     = 921600;
static const uint16_t W        = 240;
static const uint16_t H        = 320;
static const uint16_t STRIP_H  = 16;              // rows per strip
static const uint16_t NSTRIP   = H / STRIP_H;     // 20
static const uint32_t FRAME_MS = 0;               // no artificial gap between diff passes
static const int      BUDGET   = 8;               // strips scanned per service() call

static bool     streaming = false;
static bool     forceAll  = false;
static uint16_t curStrip  = 0;
static uint32_t lastFrame = 0;
static uint16_t stripBuf[W * STRIP_H];            // 240*16 = 7.5 KB scratch
static uint32_t stripHash[NSTRIP] = {0};

// ───────── virtual buttons (indexed by pin) ─────────
static const int      MAXPIN  = 50;
static const uint16_t HOLD_MS = 150;
static uint32_t vExpire[MAXPIN] = {0};
static bool     vEdge[MAXPIN]   = {false};

static void pressPin(int pin) {
  if (pin < 0 || pin >= MAXPIN) return;
  vExpire[pin] = millis() + HOLD_MS;
  vEdge[pin]   = true;
}
bool virtualDown(int pin) {
  if (pin < 0 || pin >= MAXPIN) return false;
  return (int32_t)(vExpire[pin] - millis()) > 0;
}
bool virtualEdge(int pin) {
  if (pin < 0 || pin >= MAXPIN) return false;
  if (vEdge[pin]) { vEdge[pin] = false; return true; }
  return false;
}

// ───────── host commands ─────────
static void startStream() {
  streaming = true;
  forceAll  = true;
  curStrip  = 0;
  lastFrame = 0;
  for (uint16_t i = 0; i < NSTRIP; i++) stripHash[i] = 0;
  Serial.printf("DIM %u %u\n", W, H);
}
static void readCommands() {
  while (Serial.available()) {
    int c = Serial.read();
    switch (c) {
      case 'u': pressPin(BTN_UP);     break;
      case 'd': pressPin(BTN_DOWN);   break;
      case 'l': pressPin(BTN_LEFT);   break;
      case 'r': pressPin(BTN_RIGHT);  break;
      case 'k': pressPin(BTN_SELECT); break;
      case '1': startStream();        break;
      case '0': streaming = false;    break;
      case 'p': Serial.print("DIV2\n"); break;
      default:  break;
    }
  }
}

// ───────── diff + send one strip ─────────
static uint32_t fnv(const uint16_t* p, uint32_t n) {
  uint32_t h = 2166136261u;
  for (uint32_t i = 0; i < n; i++) { h ^= p[i]; h *= 16777619u; }
  return h;
}

static void scanStrip() {
  uint16_t y = curStrip * STRIP_H;
  tft.readRect(0, y, W, STRIP_H, stripBuf);
  uint32_t h = fnv(stripBuf, (uint32_t)W * STRIP_H);
  if (forceAll || h != stripHash[curStrip]) {
    stripHash[curStrip] = h;
    Serial.printf("STR %u %u %u\n", y, W, STRIP_H);
    Serial.write((uint8_t*)stripBuf, (size_t)W * STRIP_H * 2);  // native LE: lo,hi
  }
  curStrip++;
  if (curStrip >= NSTRIP) { curStrip = 0; lastFrame = millis(); forceAll = false; }
}

// ───────── API ─────────
void begin() {
#if defined(ARDUINO_USB_CDC_ON_BOOT) && ARDUINO_USB_CDC_ON_BOOT
  // Native USB CDC: baud is irrelevant, and a blocking write stalls the UI
  // loop when the host is slow -> the port appears to "disconnect". Make
  // writes non-blocking (drop instead of stall); the diff resends next frame.
  Serial.setTxTimeoutMs(0);
#else
  // real UART bridge: raise the line rate for throughput
  Serial.updateBaudRate(BAUD);
#endif
  streaming = false;
  curStrip  = 0;
  lastFrame = 0;
}

void service() {
  readCommands();
  if (!streaming) return;
  if (curStrip == 0 && (millis() - lastFrame) < FRAME_MS) return;  // pace passes
  int budget = BUDGET;
  while (budget-- > 0 && streaming) {
    scanStrip();
    if (curStrip == 0) break;   // finished a full pass
  }
}

} // namespace Remote
