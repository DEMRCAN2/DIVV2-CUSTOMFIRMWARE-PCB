// guardian.cpp — invisible background protector
// Part of DIVV2-CUSTOMFIRMWARE-PCB (DEMRCAN2)
//
// No UI. Guardian::tick() is called from the button-poll path (so it runs
// inside every menu and every feature loop, including long jam/scan/promisc
// runs). It feeds the loop-task watchdog so a long, busy operation can't trip
// a reset mid-attack. SD-bus recovery is handled globally in isSDCardAvailable()
// (soft remount + retries), so a dropped card re-mounts itself without a reboot.

#include "config.h"
#include <esp_task_wdt.h>

namespace Guardian {

void tick() {
  esp_task_wdt_reset();   // keep the watchdog happy during long operations
}

} // namespace Guardian
