#pragma once
#include <Arduino.h>

// USB screen-mirror + control bridge (qFlipper-style).
// service() is called from the button-poll functions, so it runs in the UI
// thread between draws — no background task, no SPI contention. The host app
// connects over USB serial, requests the framebuffer and injects button taps.
namespace Remote {
  void begin();                 // call once in setup() (after Serial.begin)
  void service();               // cheap; call from every button-poll path
  bool virtualDown(int pin);    // level: host is "holding" this button
  bool virtualEdge(int pin);    // one-shot: a fresh host tap on this button
}
